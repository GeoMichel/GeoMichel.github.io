package com.example.myapplication;

public class Camp {
    // instance variables
    private int var_id;
    private String var_location;
    private String var_name;
    // empty constructor
    public Camp() { }
    // constructor with all three variables
    public Camp(int id, String location, String name) {
        this.var_id = id;
        this.var_location = location;
        this.var_name = name;
    }
    // constructor without id
    public Camp(String location, String name) {
        this.var_location = location;
        this.var_name = name;
    }
    // setters (mutators)
    public void setID(int id) { this.var_id = id; }
    public void setName(String name) { this.var_name = name; }
    public void setLocation(String location) { this.var_location = location; }
    // getters (accessors)
    public int getID() { return this.var_id; }
    public String getName() { return this.var_name; }
    public String getLocation() { return this.var_location; }
}