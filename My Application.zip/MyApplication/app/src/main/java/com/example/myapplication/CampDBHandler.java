package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObservable;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
/**
 * Created by e.lavieri on 8/4/2017.
 * For SNHU: COCE.
 * Target: CS360 Module Three.
 */
public class CampDBHandler extends SQLiteOpenHelper{
    // database name and version
    private static final int DB_VER = 1;
    private static final String DB_NAME = "campDB.db";
    // table
    public static final String TABLE_CAMPS = "camps";
    // columns
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_LOCATION = "location";
    // constructor
    public CampDBHandler(Context context, String name,
                         SQLiteDatabase.CursorFactory factory, int version)
    {
        super(context, DB_NAME, factory, DB_VER);
    }
    // This method creates the Camps table when the DB is initialized.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CAMPS_TABLE = "CREATE TABLE " +
                TABLE_CAMPS + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY," +
                COLUMN_NAME + " TEXT," +
                COLUMN_LOCATION + " TEXT" + ")";
        db.execSQL(CREATE_CAMPS_TABLE);
    }
    // This method closes an open DB if a new one is created.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CAMPS);
        onCreate(db);
    }
    // This method is used to add a Camp record to the database.
    public void addCamp(com.example.myapplication.Camp camp) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, camp.getName());
        values.put(COLUMN_LOCATION, camp.getLocation());
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_CAMPS, null, values);
        db.close();
    }
    // implements the search/find functionality
    public com.example.myapplication.Camp searchCamp(String campName) {
        String query = "SELECT * FROM " +
                TABLE_CAMPS + " WHERE " + COLUMN_NAME +
                " = \"" + campName + "\"";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        com.example.myapplication.Camp camp = new com.example.myapplication.Camp();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            camp.setID(Integer.parseInt(cursor.getString(0)));
            camp.setName(cursor.getString(1));
            camp.setLocation(cursor.getString(2));
            cursor.close();
        } else {
            camp = null;
        }
        db.close();
        return camp;
    }
    // implements the delete camp functionality
    public boolean deleteCamp(String campName) {
        boolean result = false;
        String query = "SELECT * FROM " + TABLE_CAMPS +
                " WHERE " + COLUMN_NAME + " = \"" + campName + "\"";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        com.example.myapplication.Camp camp = new com.example.myapplication.Camp();
        if (cursor.moveToFirst()) {
            camp.setID(Integer.parseInt(cursor.getString(0)));
            db.delete(TABLE_CAMPS, COLUMN_ID + " = ?",
                    new String[] { String.valueOf(camp.getID())});
            cursor.close();
            result = true;
        }
        db.close();
        return result;
    }
}
