package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button12);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                openfacebook();
            }
        });

        Button camerabtn = (Button)findViewById(R.id.camerabtn);

        camerabtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,0);
            }
        });

        Button mapbtn = findViewById(R.id.mapbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openmap();
            }
        });

        Button campbtn = findViewById((R.id.campbtn));
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencamp();
            }
        });
    }
    public void openfacebook(){
        Intent intent = new Intent(this, facebook.class);
        startActivity(intent);
    }
    public void openmap(){
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
    }
    public void opencamp(){
        Intent intent = new Intent(this, CampDBHandler.class);
        startActivity(intent);
    }
}
