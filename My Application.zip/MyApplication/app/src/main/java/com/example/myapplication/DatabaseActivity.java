package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Created by e.lavieri on 8/4/2017.
 * For SNHU: COCE.
 * Target: CS360 Module Three.
 */
public class DatabaseActivity extends AppCompatActivity {
    TextView idView;
    EditText nameBox;
    EditText locationBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        idView = findViewById(R.id.campID);
        nameBox = findViewById(R.id.campName);
        locationBox = findViewById(R.id.campLocation);
    }
    public void newCamp(View view) {
        com.example.myapplication.CampDBHandler dbHandler = new com.example.myapplication.CampDBHandler(this, null, null, 1);
        String location = (locationBox.getText().toString());
        com.example.myapplication.Camp camp = new com.example.myapplication.Camp(location, nameBox.getText().toString());
        dbHandler.addCamp(camp);
        nameBox.setText("");
        locationBox.setText("");
    }
    public void searchForCamp(View view) {
        com.example.myapplication.CampDBHandler dbHandler = new com.example.myapplication.CampDBHandler(this, null, null, 1);
        com.example.myapplication.Camp camp = dbHandler.searchCamp(nameBox.getText().toString());
        if (camp != null) {
            idView.setText(String.valueOf(camp.getID()));
            locationBox.setText(String.valueOf(camp.getLocation()));
        } else {
            idView.setText("Camp not found.");
        }
    }
    public void deleteCamp(View view) {
        com.example.myapplication.CampDBHandler dbHandler = new com.example.myapplication.CampDBHandler(this, null, null, 1);
        boolean result = dbHandler.deleteCamp(nameBox.getText().toString());
        if (result)
        {
            idView.setText("Camp Deleted");
            nameBox.setText("");
            locationBox.setText("");
        }
        else
            idView.setText("Camp not found.");
    }
}


