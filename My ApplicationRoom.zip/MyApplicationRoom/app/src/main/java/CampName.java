import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "CampName_table")
public class CampName {
    @PrimaryKey(autoGenerate = true)
    private int Campid;
    @NonNull
    private String camp;
    @ColumnInfo(name = "Camp")
    private String mCampName;

    public CampName(int campid, @NonNull String word) {
        Campid = campid;
        this.mCampName = word;}

    public String getWord(){return this.mCampName;}

    public int getcampName() {
    }
}
}
