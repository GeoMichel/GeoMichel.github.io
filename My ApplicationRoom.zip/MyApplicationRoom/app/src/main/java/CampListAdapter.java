import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplicationroom.R;

import java.util.List;

public class CampListAdapter extends RecyclerView.Adapter<CampListAdapter.CampViewHolder> {

    class CampViewHolder extends RecyclerView.ViewHolder {
        private final TextView campItemView;

        private CampViewHolder(View itemView) {
            super(itemView);
            campItemView = itemView.findViewById(R.id.textView);
        }
    }

    private final LayoutInflater mInflater;
    private List<CampName> mCampNames; // Cached copy of campnames

    CampListAdapter(Context context) { mInflater = LayoutInflater.from(context); }

    @Override
    public CampViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recyclerview_item, parent, false);
        return new CampViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(CampViewHolder holder, int position) {
        if (mCampNames != null) {
            CampName current = mCampNames.get(position);
            holder.campItemView.setText(current.getcampName());
        } else {
            // Covers the case of data not being ready yet.
            holder.campItemView.setText("No Camp");
        }
    }

    void setWords(List<CampName> campNames){
        mCampNames = campNames;
        notifyDataSetChanged();
    }

    // getItemCount() is called many times, and when it is first called,
    // mWords has not been updated (means initially, it's null, and we can't return null).
    @Override
    public int getItemCount() {
        if (mCampNames != null)
            return mCampNames.size();
        else return 0;
    }