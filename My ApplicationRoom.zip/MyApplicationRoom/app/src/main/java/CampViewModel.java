import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class CampViewModel extends AndroidViewModel {

    private CampNameRepository mRepository;

    private LiveData<List<CampName>> mAllCampNames;

    public CampViewModel (Application application) {
        super(application);
        mRepository = new CampNameRepository();
        mAllCampNames = mRepository.getAllCampName();
    }

    LiveData<List<CampName>> getAllCampNames() { return mAllCampNames; }

    public void insert(CampName camp) { mRepository.insert(camp); }
}